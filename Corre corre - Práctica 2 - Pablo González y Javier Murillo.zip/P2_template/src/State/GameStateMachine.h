#pragma once

#include <stack>
#include "State.h"

class GameStateMachine
{
private:
	// Pila de estados
	stack<State*> states;

public:
	// Constructoras y destructora
	GameStateMachine() {};
	GameStateMachine(State* firstState);
	~GameStateMachine();

	// M�todos de gesti�n de estados
	State* currentState() { return states.top(); };
	void pushState(State* _state);
	void changeState(State* newState);
	void popState();
	void discardStates();
};