#include "Game.h"
#include "Player.h"
#include "PlayState.h"

Game::Game(){
    // TODO create settings
    ROAD_WIDTH = 2000;
    ROAD_LENGTH = 10000;

    gsm = new GameStateMachine();

    srand(time(0));

    generator = new GameObjectGenerator(this);
    bDebug = false;
    scream.load("aaa.wav");
    timer = 0;
}

Game::~Game(){
    ofLogNotice() << "Deleting game";
    delete gameObjects;
    delete generator;
    delete currentState();
    delete gsm;
}

void Game::init(){
    
    if(gameObjects != nullptr)
        delete gameObjects;
    
    
    gameObjects = new GameObjectContainer();
    
    player = new Player(this);
    player->init();

    cam.setPosition(0, 300, -600);
    cam.setTarget(player->transform);
    cam.setParent(player->transform);
    //cam.disableMouseInput();
    cam.setFarClip(100000);
    
    gameObjects->add(player);
    generator->generateWorld();
}

void Game::update(){
    if (dynamic_cast<PlayState*>(gsm->currentState()) != nullptr) {
        gameObjects->update();
        timer += ofGetLastFrameTime();
    }
}

void Game::draw(){
    if (dynamic_cast<PlayState*>(gsm->currentState()) != nullptr) {
        ofEnableLighting();
        ofEnableDepthTest();
        
        cam.begin();
        {
            if(bDebug) gameObjects->drawDebug();
            else gameObjects->draw();
        }
        cam.end();
    
        ofDisableLighting();
        ofDisableDepthTest();
    }
}

Player * Game::getPlayer(){
    return player;
}

vector<GameObject *> Game::getCollisions(GameObject *gameObject){
    return gameObjects->getCollisions(gameObject);
}

void  Game::addGameObject(GameObject *gameobject){
    gameObjects->add(gameobject);
}

void Game::toggleDebug(){
    bDebug = !bDebug;
}

float Game::getEllapsedTime(){
    return timer;
}

void Game::doScream(){
    scream.play();
}
